"""Business rules taken from the original scripts."""

# Section_h.py / Firstphase.py thresholds
TEMP_WARN, TEMP_CRIT = 80, 100
VIB_WARN, VIB_CRIT = 5, 8
# Availability rule corrected: the original compared "> 90" / "> 100".
AVAIL_WARN, AVAIL_CRIT = 90, 80


def equipment_alerts(row):
    """Return a list of (level, message) for one equipment row."""
    out = []
    t, v, a = row["Temperature_C"], row["Vibration_mm_s"], row["Availability_percent"]
    if t > TEMP_CRIT:
        out.append(("CRITICAL", f"Temperature {t}°C is above {TEMP_CRIT}°C"))
    elif t >= TEMP_WARN:
        out.append(("WARNING", f"Temperature {t}°C is in the {TEMP_WARN}-{TEMP_CRIT}°C range"))
    if v > VIB_CRIT:
        out.append(("CRITICAL", f"Vibration {v} mm/s is above {VIB_CRIT}"))
    elif v >= VIB_WARN:
        out.append(("WARNING", f"Vibration {v} mm/s is in the {VIB_WARN}-{VIB_CRIT} range"))
    if a < AVAIL_CRIT:
        out.append(("CRITICAL", f"Availability {a}% is below {AVAIL_CRIT}%"))
    elif a < AVAIL_WARN:
        out.append(("WARNING", f"Availability {a}% is below {AVAIL_WARN}%"))
    for part in ("Brake", "Tyre", "Engine"):
        s = row[f"{part}_Status"]
        if s != "Good":
            out.append(("CRITICAL" if s == "Critical" else "WARNING", f"{part} status: {s}"))
    if row["Maintenance_Status"] == "Due":
        out.append(("WARNING", "Maintenance is due"))
    return out


def risk_level(score):
    """Risk_Assessment.py: likelihood x consequence."""
    if 1 <= score <= 4:
        return "Low"
    if score <= 9:
        return "Medium"
    if score <= 16:
        return "High"
    if score <= 25:
        return "Critical"
    return "Invalid"
