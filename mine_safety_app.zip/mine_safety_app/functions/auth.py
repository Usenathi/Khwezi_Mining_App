"""Login + role-based access control (from aANDb.py and the login database)."""
import hmac
import streamlit as st
from functions.data_loader import load_users

ROLES = {
    "Administrator": ["dashboard", "workers", "incidents", "equipment", "maintenance", "risk", "reports", "users"],
    "Safety Officer": ["dashboard", "workers", "incidents", "risk", "reports"],
    "Mining Engineer": ["dashboard", "workers", "equipment", "maintenance", "risk", "reports"],
    "Maintenance Engineer": ["dashboard", "equipment", "maintenance", "reports"],
    "Manager": ["dashboard", "workers", "incidents", "equipment", "maintenance", "risk", "reports"],
}


def current_user():
    return st.session_state.get("user")


def login_form():
    st.subheader("Sign in")
    with st.form("login"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        go = st.form_submit_button("Sign in")
    if go:
        users = load_users()
        match = users[users["Username"].astype(str).str.lower() == username.strip().lower()]
        if not match.empty and hmac.compare_digest(str(match.iloc[0]["Password"]), password):
            st.session_state["user"] = match.iloc[0][["Name", "Username", "Role"]].to_dict()
            st.rerun()
        st.error("Invalid username or password.")


def sidebar_user():
    user = current_user()
    if user:
        st.sidebar.write(f"**{user['Name']}**  \n{user['Role']}")
        if st.sidebar.button("Sign out"):
            st.session_state.pop("user", None)
            st.rerun()


def require_access(page_key):
    user = current_user()
    if not user:
        st.warning("Please sign in on the Home page first.")
        st.stop()
    sidebar_user()
    if page_key not in ROLES.get(user["Role"], []):
        st.error(f"Your role ({user['Role']}) does not have access to this page.")
        st.stop()


def page_header(title, subtitle=""):
    st.title(title)
    if subtitle:
        st.caption(subtitle)
