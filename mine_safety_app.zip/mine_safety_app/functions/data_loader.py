"""Loads the CSV databases from the data/ folder."""
from pathlib import Path
import pandas as pd
import streamlit as st

DATA = Path(__file__).resolve().parent.parent / "data"
INCIDENTS_FILE = DATA / "safety_incidents_database.csv"


def _read(name):
    try:
        return pd.read_csv(DATA / name)
    except Exception as err:  # missing or unreadable file
        st.error(f"Could not load {name}: {err}")
        return pd.DataFrame()


@st.cache_data
def load_workers():
    return _read("workers_database.csv")


@st.cache_data
def load_incidents():
    return _read("safety_incidents_database.csv")


@st.cache_data
def load_equipment():
    return _read("equipment_database.csv")


@st.cache_data
def load_users():
    return _read("login_database.csv")


def save_incident(record: dict):
    """Append one incident to the CSV so it survives restarts."""
    df = pd.concat([load_incidents(), pd.DataFrame([record])], ignore_index=True)
    df.to_csv(INCIDENTS_FILE, index=False)
    load_incidents.clear()
