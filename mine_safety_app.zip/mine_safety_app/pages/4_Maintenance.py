import streamlit as st
from functions.auth import require_access, page_header
from functions.data_loader import load_equipment
from functions.rules import equipment_alerts

st.set_page_config(page_title="Maintenance", page_icon="🔧", layout="wide")
require_access("maintenance")
page_header("🔧 Maintenance & Alerts")

e = load_equipment()
rows = [(r["Equipment_ID"], r["Equipment_Type"], lvl, msg) for _, r in e.iterrows() for lvl, msg in equipment_alerts(r)]
rows.sort(key=lambda x: x[2] != "CRITICAL")

a, b, c = st.columns(3)
a.metric("Maintenance due", int((e.Maintenance_Status == "Due").sum()))
b.metric("Avg downtime (hr)", f"{e.Downtime_hr.mean():.1f}")
c.metric("Engine critical", int((e.Engine_Status == "Critical").sum()))

st.subheader(f"Alerts ({len(rows)})")
for eid, typ, lvl, msg in rows:
    (st.error if lvl == "CRITICAL" else st.warning)(f"**{eid}** ({typ}) - {msg}")

st.subheader("Maintenance due")
st.dataframe(e[e.Maintenance_Status == "Due"], use_container_width=True)
