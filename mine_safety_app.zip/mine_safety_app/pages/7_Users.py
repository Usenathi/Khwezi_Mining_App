import streamlit as st
from functions.auth import require_access, page_header, ROLES
from functions.data_loader import load_users

st.set_page_config(page_title="Users", page_icon="👥", layout="wide")
require_access("users")
page_header("👥 Users", "Accounts and what each role can access.")

u = load_users()[["Name", "Username", "Role"]].copy()
u["Access"] = u.Role.map(lambda r: ", ".join(ROLES.get(r, [])))
st.dataframe(u, use_container_width=True)
