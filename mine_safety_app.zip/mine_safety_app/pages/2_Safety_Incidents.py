from datetime import datetime
import streamlit as st
from functions.auth import require_access, page_header
from functions.data_loader import load_incidents, save_incident

st.set_page_config(page_title="Safety Incidents", page_icon="⚠️", layout="wide")
require_access("incidents")
page_header("⚠️ Safety Incidents", "Search, filter and record incidents.")

i = load_incidents()
q = st.text_input("Search (ID, worker, cause...)")
cols = st.columns(5)
sev = cols[0].selectbox("Severity", ["All"] + sorted(i.Severity.unique()))
shift = cols[1].selectbox("Shift", ["All"] + sorted(i.Shift.unique()))
typ = cols[2].selectbox("Incident type", ["All"] + sorted(i.Incident_Type.unique()))
dep = cols[3].selectbox("Department", ["All"] + sorted(i.Department.dropna().unique()))
status = cols[4].selectbox("Status", ["All"] + sorted(i.Incident_Status.unique()))

f = i.copy()
for col, val in [("Severity", sev), ("Shift", shift), ("Incident_Type", typ), ("Department", dep), ("Incident_Status", status)]:
    if val != "All":
        f = f[f[col] == val]
if q:
    f = f[f.astype(str).apply(lambda r: q.lower() in " ".join(r).lower(), axis=1)]

st.caption(f"{len(f)} of {len(i)} incidents")
st.dataframe(f, use_container_width=True)
a, b = st.columns(2)
a.subheader("By severity")
a.bar_chart(f.Severity.value_counts())
b.subheader("By cause")
b.bar_chart(f.Cause.value_counts())

with st.expander("➕ Add incident"):
    with st.form("add"):
        c = st.columns(3)
        worker = c[0].text_input("Worker name")
        shift_n = c[1].selectbox("Shift ", ["Day", "Night"])
        loc = c[2].selectbox("Location", sorted(i.Location.unique()))
        c = st.columns(3)
        dep_n = c[0].selectbox("Department ", sorted(i.Department.dropna().unique()))
        typ_n = c[1].selectbox("Incident type ", sorted(i.Incident_Type.unique()))
        sev_n = c[2].selectbox("Severity ", ["Minor", "Moderate", "Serious", "Critical"])
        cause = st.selectbox("Cause", sorted(i.Cause.unique()))
        if st.form_submit_button("Save incident"):
            now = datetime.now()
            save_incident({
                "Incident_ID": f"INC-{len(i) + 1:03d}",
                "Date": now.strftime("%Y/%m/%d"), "Time": now.strftime("%H:%M"),
                "Shift": shift_n, "Location": loc, "Department": dep_n,
                "Worker_ID": "", "Worker_Name": worker or "Unknown", "Job_Role": "",
                "Incident_Type": typ_n, "Severity": sev_n, "Injury_Status": "No",
                "Lost_Time": "No", "Cause": cause, "Corrective_Action": "",
                "Incident_Status": "Open",
            })
            st.success("Incident saved.")
            st.rerun()
