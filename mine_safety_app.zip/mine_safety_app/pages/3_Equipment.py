import streamlit as st
from functions.auth import require_access, page_header
from functions.data_loader import load_equipment
from functions.rules import equipment_alerts

st.set_page_config(page_title="Equipment", page_icon="🚜", layout="wide")
require_access("equipment")
page_header("🚜 Equipment", "Temperature <80 normal, 80-100 warning, >100 critical. Vibration <5 normal, 5-8 warning, >8 critical.")

e = load_equipment()
a, b, c = st.columns(3)
typ = a.selectbox("Type", ["All"] + sorted(e.Equipment_Type.unique()))
cond = b.selectbox("Condition", ["All", "NORMAL", "WARNING", "CRITICAL"])
eid = c.text_input("Equipment ID (e.g. E001)").strip().upper()

f = e.copy()
if typ != "All":
    f = f[f.Equipment_Type == typ]
if cond != "All":
    f = f[f.Condition == cond]
if eid:
    f = f[f.Equipment_ID == eid]
    if f.empty:
        st.error("Equipment ID not found.")

st.dataframe(f, use_container_width=True)
if len(f) == 1:
    st.subheader(f"Alerts for {f.iloc[0].Equipment_ID}")
    found = equipment_alerts(f.iloc[0])
    if not found:
        st.success("No alerts - equipment is normal.")
    for level, msg in found:
        (st.error if level == "CRITICAL" else st.warning)(f"{level}: {msg}")
