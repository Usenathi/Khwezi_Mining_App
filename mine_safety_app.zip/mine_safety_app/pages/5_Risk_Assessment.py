import pandas as pd
import streamlit as st
from functions.auth import require_access, page_header
from functions.rules import risk_level

st.set_page_config(page_title="Risk Assessment", page_icon="🎯", layout="wide")
require_access("risk")
page_header("🎯 Risk Assessment", "Risk score = likelihood x consequence (1-5 each).")

a, b = st.columns(2)
likelihood = a.slider("Likelihood", 1, 5, 3)
consequence = b.slider("Consequence", 1, 5, 3)
score = likelihood * consequence
st.metric("Risk score", score, risk_level(score), delta_color="off")
st.caption("1-4 Low | 5-9 Medium | 10-16 High | 17-25 Critical")

matrix = pd.DataFrame(
    [[l * c for c in range(1, 6)] for l in range(5, 0, -1)],
    index=[f"L{l}" for l in range(5, 0, -1)], columns=[f"C{c}" for c in range(1, 6)],
)
st.dataframe(matrix)
