import streamlit as st
from functions.auth import require_access, page_header
from functions.data_loader import load_workers

st.set_page_config(page_title="Worker Safety", page_icon="👷", layout="wide")
require_access("workers")
page_header("👷 Worker Health & Safety", "Monitor worker safety indicators and risk levels.")

w = load_workers()
if w.empty:
    st.warning("Worker database could not be loaded.")
    st.stop()

a, b, c, d = st.columns(4)
a.metric("Workers", len(w))
b.metric("PPE Compliance", f"{(w.PPE_Compliance == 'Compliant').mean() * 100:.1f}%")
c.metric("High Fatigue (4-5)", int((w.Fatigue_Level >= 4).sum()))
d.metric("High/Critical Risk", int(w.Risk_Level.isin(["High", "Critical"]).sum()))

a, b, c = st.columns(3)
dep = a.selectbox("Department", ["All"] + sorted(w.Department.unique()))
shift = b.selectbox("Shift", ["All"] + sorted(w.Shift.unique()))
risk = c.selectbox("Risk Level", ["All"] + sorted(w.Risk_Level.unique()))

f = w.copy()
if dep != "All":
    f = f[f.Department == dep]
if shift != "All":
    f = f[f.Shift == shift]
if risk != "All":
    f = f[f.Risk_Level == risk]

st.dataframe(f, use_container_width=True)
st.subheader("Risk Level Distribution")
st.bar_chart(f.Risk_Level.value_counts())
st.subheader("Fatigue Level Distribution (1-5)")
st.bar_chart(f.Fatigue_Level.value_counts().sort_index())
