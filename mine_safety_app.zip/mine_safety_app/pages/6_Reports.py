from datetime import date
import streamlit as st
from functions.auth import require_access, page_header, current_user
from functions.data_loader import load_workers, load_incidents, load_equipment
from functions.rules import equipment_alerts

st.set_page_config(page_title="Reports", page_icon="📄", layout="wide")
require_access("reports")
page_header("📄 Reports")

w, i, e = load_workers(), load_incidents(), load_equipment()
alerts = sum(len(equipment_alerts(r)) for _, r in e.iterrows())
user = current_user()
report = f"""MINE SAFETY & EQUIPMENT REPORT - {date.today()}
Prepared by: {user['Name']} ({user['Role']})

WORKERS ({len(w)})
- PPE non-compliant: {int((w.PPE_Compliance != 'Compliant').sum())}
- Expired safety training: {int((w.Safety_Training_Status == 'Expired').sum())}
- High/Critical risk: {', '.join(w[w.Risk_Level.isin(['High', 'Critical'])].Name) or 'none'}

INCIDENTS ({len(i)})
- Open or under investigation: {int((i.Incident_Status != 'Closed').sum())}
- Critical severity: {int((i.Severity == 'Critical').sum())}
- Most common type: {i.Incident_Type.value_counts().index[0]}

EQUIPMENT ({len(e)})
- Critical: {', '.join(e[e.Condition == 'CRITICAL'].Equipment_ID) or 'none'}
- Maintenance due: {int((e.Maintenance_Status == 'Due').sum())}
- Active alerts: {alerts}
"""
st.code(report, language=None)
st.download_button("Download report (.txt)", report, file_name="safety_report.txt")
