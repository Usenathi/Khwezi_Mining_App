# -*- coding: utf-8 -*-
"""
Created on Tue Sep 29 11:06:13 2026

@author: Usenathi
"""

# Conveyor Belt Monitoring

# Store conveyor belt information
speed = 4.5  
Threshold_speed = 5.0        # meters per second
identifier = "CB-101"
status = "Running"   # can be "Running" or "Stopped"

# Conditional logic to check safety
if status == "Running" and speed <= Threshold_speed:
    print(f"Belt {identifier} is running safely.")
elif status == "Running" and speed > Threshold_speed:
    print(f"Belt {identifier} requires inspection (speed too high).")
else:
    print(f"Belt {identifier} is not running.")

temperature = 30.0
humidity = 70

temp_threshold = 30.0
humidity_threshold = 65

if temperature > temp_threshold and humidity > humidity_threshold:
    print("Unsafe working conditions")
else:
    print("Conditions acceptable")
    
# Slope Stability Check

# Variables
slope_angle = 45
rock_type = "Sandstone"

# Critical values for different rock types
critical_values = {
    "Sandstone": 40,
    "Limestone": 35,
    "Granite": 50,
    "Shale": 30
}

# Conditional logic
if slope_angle > critical_values[rock_type]:
    print("High Risk of Failure.")
else:
    print("Slope Stable.")

ore_grades=[36.5, 25.6, 15.6, 17.1, 21.3]
for grade in ore_grades:
    print(grade)
    
mine1 = "Kolomela"
mine2 = Mamatwane 

print(mine1.upper())
print(mine2.upper())