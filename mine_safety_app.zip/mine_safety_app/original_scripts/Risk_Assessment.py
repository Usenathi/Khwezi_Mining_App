Likelihood = int(input("Enter likelihood chances"))      # Ranges from 1 to 5
Consequence = int(input("Enter consequence chances"))    # Ranges from 1 to 5
Riskscore = Likelihood * Consequence                     #Riskscore cannot exceed 25
if Riskscore >= 1 and Riskscore <= 4:
    print ("Low Risk")
elif Riskscore >= 5 and Riskscore <= 9:
    print("Medium Risk")
elif Riskscore >= 10 and Riskscore <= 16:
    print("High Risk")
elif Riskscore >= 17 and Riskscore <= 25:
    print("Critical Risk")
else:
    print("Invalid input")