import pandas as pd

file_path = r"C:\Users\nkwad\OneDrive - University of Witwatersrand\Desktop\equipment_database.csv"
df = pd.read_csv(file_path)

#Thresholds
thresholds = {
    "Temperature_C": {"warning": 80, "critical": 100},
    "Vibration_mm_s": {"warning": 5, "critical": 8},
    "Availability_percent": {"warning": 90, "critical": 100},
    "Downtime_hr": {"warning": 100, "critical": 110},
}


def generate_alert(entity_id, parameter, value):
    if parameter not in thresholds:
        return None

    limits = thresholds[parameter]

    if value > limits["critical"]:
        status = "CRITICAL"
        action = "Immediate inspection/maintenance required."
    elif value > limits["warning"]:
        status = "WARNING"
        action = "Monitor closely and schedule inspection soon."
    else:
        status = "NORMAL"
        action = "No immediate action required."

    alert_message = f"""
    ===============================================
    MINING MONITORING ALERT
    ===============================================
    [{status}]

    ID: {entity_id}
    Parameter: {parameter}
    Value: {value}
    Status: {status}

    Recommended Action:
    - {action}
    ===============================================
    """
    return alert_message


for _, row in df.iterrows():
    equipment_id = row["Equipment_ID"]
    for param in thresholds.keys():
        value = row[param]
        alert = generate_alert(equipment_id, param, value)
        if alert:
            print(alert)
