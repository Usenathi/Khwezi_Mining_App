# -*- coding: utf-8 -*-
"""
Created on Sun Oct  4 15:36:50 2026

@author: Usenathi
"""
import pandas as pd

equipment_data = pd.read_csv("data/Equipment_data.csv")

print("\n--- Equipment Maintenance Monitoring ---")
Equipment_ID = input("Enter Equipment ID (e.g. E001): ").strip()
equipment = equipment_data[
    equipment_data["Equipment_ID"].astype(str).str.strip() == Equipment_ID
]
if equipment.empty:
    print("\nERROR: Equipment ID not found.")
else:
    machine = equipment.iloc[0]

    Equipment_Type = machine["Equipment_Type"]
    Manufacturer = machine["Manufacturer"]
    Operating_hrs = machine["Operating_Hours"]
    Downtime_hrs = machine["Downtime_hr"]
    Maintenance_Status = machine["Maintenance_Status"]

    Alerts = int(input("Enter Number of Alerts: "))

    Availability = (
        Operating_hrs /
        (Operating_hrs + Downtime_hrs)
    ) * 100

    print("\n--- Equipment Information ---")

    print("Equipment ID:", Equipment_ID)
    print("Equipment Type:", Equipment_Type)
    print("Manufacturer:", Manufacturer)
    print("Operating Hours:", Operating_hrs)
    print("Downtime:", Downtime_hrs)
    print("Maintenance Status:", Maintenance_Status)
    print("Number of Alerts:", Alerts)
    print("Equipment Availability:", round(Availability, 2), "%")
              
if Maintenance_Status == "Overdue": 
    print("WARNING: Equipment is overdue for maintenance.") 
elif Maintenance_Status == "Due": 
        print("WARNING: Equipment is due for maintenance.") 
elif Maintenance_Status == "Good": 
    print("Equipment maintenance is up to date.") 
else: 
    print("Invalid maintenance status.")
    
if Downtime_hrs == 100: 
    print("WARNING: Equipment has excessive downtime.") 
elif Downtime_hrs >= 100: 
    print("Critical: Equipment has excessive downtime.")
else: 
    print("Equipment downtime is acceptable.") 
    
if Alerts >= 3: 
    print("WARNING: Equipment has repeated alerts.") 
else: 
    print("Equipment alerts are normal.") 
# Check availability 
if Availability == 90: 
    print("WARNING: Equipment has low availability.")
elif Availability >= 100:
    print("Critical: Equipment has low availability.")   
else: 
    print("Equipment availability is good.") 