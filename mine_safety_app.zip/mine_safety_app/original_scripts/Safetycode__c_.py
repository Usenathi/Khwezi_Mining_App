# -*- coding: utf-8 -*-
"""
Created on Mon Sep 28 09:47:20 2026

@author: Usenathi
"""

incidents = []


def add_incident():

    print("\n___ ADD SAFETY INCIDENT ___")

    Incident_ID = input("Insert Incident ID: ")
    Date = input("Insert Date (DD/MM/YY): ")
    Time = input("Insert Time: ")
    Shift = input("Insert Shift (Night/Day): ")
    Location = input("Insert Location (Mine Site): ")
    Department = input("Insert Department: ")
    Incident_type = input(
        "Insert Incident Type (Fall of Ground, Machinery Accident, etc.): "
    )
    Severity = input(
        "Enter Severity Level (Critical, High, Medium, Low): "
    )
    Lost_time = input(
        "Enter Lost-Time Injury Status (Yes/No): "
    )
    Cause = input("What is the Cause: ")
    Corrective_action = input(
        "Enter Corrective Action Priority (High, Medium, Low): "
    )
    Status = input("Enter Incident Status (Open/Closed): ")

    incident = {
        "ID": Incident_ID,
        "Date": Date,
        "Time": Time,
        "Shift": Shift,
        "Location": Location,
        "Department": Department,
        "Type": Incident_type,
        "Severity": Severity,
        "Lost Time": Lost_time,
        "Cause": Cause,
        "Corrective Action": Corrective_action,
        "Status": Status
    }

    incidents.append(incident)

    print("\nIncident added successfully.")


def view_incidents():

    print("\n___ ALL SAFETY INCIDENTS ___")

    if len(incidents) == 0:
        print("No incidents have been recorded.")
    else:
        for incident in incidents:
            print(incident)


def search_incidents():

    print("\n___ SEARCH INCIDENTS ___")

    search = input("Enter Incident ID: ")

    found = False

    for incident in incidents:
        if search == incident["ID"]:
            print("Incident found")
            print(incident)
            found = True

    if found == False:
        print("No matching incidents found.")


def filter_incidents():

    print("\n___ FILTER INCIDENTS ___")
    print("1. Filter by Severity")
    print("2. Filter by Shift")
    print("3. Filter by Incident Type")
    print("4. Filter by Department")
    print("5. Filter by Location")

    choice = input("Choose a filter: ")

    if choice == "1":
        value = input("Enter Severity: ")

        for incident in incidents:
            if incident["Severity"].lower() == value.lower():
                print(incident)

    elif choice == "2":
        value = input("Enter Shift: ")

        for incident in incidents:
            if incident["Shift"].lower() == value.lower():
                print(incident)

    elif choice == "3":
        value = input("Enter Incident Type: ")

        for incident in incidents:
            if incident["Type"].lower() == value.lower():
                print(incident)

    elif choice == "4":
        value = input("Enter Department: ")

        for incident in incidents:
            if incident["Department"].lower() == value.lower():
                print(incident)

    elif choice == "5":
        value = input("Enter Location: ")

        for incident in incidents:
            if incident["Location"].lower() == value.lower():
                print(incident)

    else:
        print("Invalid choice.")


def categorize_incidents():

    print("\n___ INCIDENT CATEGORIES ___")

    if len(incidents) == 0:
        print("No incidents recorded.")
        return

    fall = 0
    machinery = 0
    fire = 0

    for incident in incidents:

        if incident["Type"].lower() == "fall of ground":
            fall = fall + 1

        elif incident["Type"].lower() == "machinery accident":
            machinery = machinery + 1

        elif incident["Type"].lower() == "fire":
            fire = fire + 1

    print("Fall of Ground:", fall)
    print("Machinery Accident:", machinery)
    print("Fire:", fire)


def count_incidents():

    print("\n___ INCIDENT COUNT ___")

    total = len(incidents)

    print("Total number of incidents:", total)

    critical = 0
    high = 0
    medium = 0
    low = 0

    for incident in incidents:

        severity = incident["Severity"].lower()

        if severity == "critical":
            critical += 1

        elif severity == "high":
            high += 1

        elif severity == "medium":
            medium += 1

        elif severity == "low":
            low += 1

    print("\nIncidents by Severity:")
    print("Critical:", critical)
    print("High:", high)
    print("Medium:", medium)
    print("Low:", low)


def analyse_trends():

    print("\n___ INCIDENT TREND ANALYSIS ___")

    print("Total number of incidents:", len(incidents))

    fall = 0
    machinery = 0
    fire = 0

    for incident in incidents:

        if incident["Type"].lower() == "fall of ground":
            fall = fall + 1

        elif incident["Type"].lower() == "machinery accident":
            machinery = machinery + 1

        elif incident["Type"].lower() == "fire":
            fire = fire + 1

    print("\nIncident Trends:")

    print("Falls of Ground:", fall)
    print("Machinery Accidents:", machinery)
    print("Fires:", fire)

    if fall > machinery and fall > fire:
        print("\nTrend: Falls of Ground are the most common.")

    elif machinery > fall and machinery > fire:
        print("\nTrend: Machinery Accidents are the most common.")

    elif fire > fall and fire > machinery:
        print("\nTrend: Fires are the most common.")

    else:
        print("\nTrend: There is no clear trend.")


print("\nSAFETY INCIDENTS DATABASE")
print("1. Add Incident")
print("2. View Incidents")
print("3. Search Incidents")
print("4. Filter Incidents")
print("5. Categorize Incidents")
print("6. Count Incidents")
print("7. Analyse Incident Trends")
print("8. Exit")

choice = input("\nSelect an option: ")

if choice == "1":
    add_incident()

elif choice == "2":
    view_incidents()

elif choice == "3":
    search_incidents()

elif choice == "4":
    filter_incidents()

elif choice == "5":
    categorize_incidents()

elif choice == "6":
    count_incidents()

elif choice == "7":
    analyse_trends()

elif choice == "8":
    print("\nThank you for using the Safety Incidents Database.")
    print("Stay safe!")

else:
    print("\nInvalid option. Please choose 1-8.")

