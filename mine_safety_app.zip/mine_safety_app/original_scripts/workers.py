import streamlit as st
import pandas as pd
from functions.auth import require_access, page_header
from functions.data_loader import load_workers, load_incidents, load_equipment
st.set_page_config(page_title="Worker Safety",page_icon="👷",layout="wide")
require_access("workers"); page_header("👷 Worker Health & Safety","Monitor worker safety indicators and risk levels.")
w=load_workers()
if w.empty: st.warning("Worker database could not be loaded."); st.stop()
a,b,c,d=st.columns(4); a.metric("Workers",len(w)); b.metric("PPE Compliance",f"{(w.PPE_Compliance.astype(str).str.lower()=="yes").mean()*100:.1f}%"); c.metric("High Fatigue",int((w.Fatigue_Level.astype(str).str.lower()=="high").sum())); d.metric("High/Critical Risk",int(w.Risk_Level.astype(str).str.lower().isin(["high","critical"]).sum()))
a,b,c=st.columns(3)
with a: dep=st.selectbox("Department",["All"]+sorted(w.Department.dropna().unique().tolist()))
with b: shift=st.selectbox("Shift",["All"]+sorted(w.Shift.dropna().unique().tolist()))
with c: risk=st.selectbox("Risk Level",["All"]+sorted(w.Risk_Level.dropna().unique().tolist()))
f=w.copy(); f=f if dep=="All" else f[f.Department==dep]; f=f if shift=="All" else f[f.Shift==shift]; f=f if risk=="All" else f[f.Risk_Level==risk]
st.dataframe(f,use_container_width=True); st.subheader("Risk Level Distribution"); st.bar_chart(f.Risk_Level.value_counts()); st.subheader("Fatigue Level Distribution"); st.bar_chart(f.Fatigue_Level.value_counts())
