# -*- coding: utf-8 -*-
"""
Created on Wed Sep  9 22:25:25 2026

@author: Usenathi
"""

# Role-Based Access Control (RBAC) demo

roles = {
    "Administrator": [
        "View dashboard", "Worker safety data", "Safety incidents",
        "Equipment data", "Maintenance data", "Risk assessment",
        "Generate reports", "Manage users"
    ],
    "Safety Officer": [
        "View dashboard", "Worker safety data", "Safety incidents",
        "Risk assessment", "Generate reports"
    ],
    "Mining Engineer": [
        "View dashboard", "Worker safety data", "Equipment data",
        "Maintenance data", "Risk assessment", "Generate reports"
    ],
    "Maintenance Engineer": [
        "View dashboard", "Equipment data", "Maintenance data",
        "Generate reports"
    ],
    "Manager": [
        "View dashboard", "Worker safety data", "Safety incidents",
        "Equipment data", "Maintenance data", "Risk assessment",
        "Generate reports"
    ]
}

role = input("Enter your role: ")

if role in roles:
    print("Access granted for {role}. You can:")
    for function in roles[role]:
        print(" -", function)
else:
    print("Invalid role. Please try again.")
    #Code for b
# Collect worker details
worker_id = input("Enter Worker ID: ")
department = input("Enter Department: ")
job_role = input("Enter Job Role: ")
shift = input("Enter Shift: ")

# Collect safety variables
ppe = input("PPE compliance (Yes/No): ")
training = input("Safety training status (Complete/Incomplete): ")
fatigue = input("Fatigue level (Low/Medium/High): ")
observations = input("Safety observations: ")
near_misses = input("Number of near misses: ")
incidents = input("Previous incidents: ")
risk = input("Risk level (Low/Medium/High): ")

# Check conditions
print("\n--- Worker Safety Report ---")
print("Worker ID:", worker_id)
print("Department:", department)
print("Job Role:", job_role)
print("Shift:", shift)

print("PPE:", ppe)
print("Training:", training)
print("Fatigue:", fatigue)
print("Observations:", observations)
print("Near Misses:", near_misses)
print("Incidents:", incidents)
print("Risk Level:", risk)

if risk.lower() == "high" or fatigue.lower() == "high" or ppe.lower() == "no":
    print("\n⚠️ Warning: Unsafe condition detected!")
else:
    print("\n✅ Worker status: Safe")