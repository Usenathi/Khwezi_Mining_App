# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 14:22:31 2026

@author: Usenathi
"""

#EQUIPMENT DATABASE
Equipment_ID= input("Enter Equipment ID:")
Equipment_type = input("Enter Equipment Type:")
Manufacture = input("Enter Manufactor:")
Operating_hrs= input("Enter Operating hours:")
Temparature = input("Enter Temperature:")
Vibration= input("Enter Vibration:")
Fuel_Consumption= input("Enter fuel consumption:")
Brake_Status=str(input("Enter Brake status"))
Tyre_Status=str(input("Enter Tyre status"))
Maintenance_Status=str(input("Enter Maintenance status"))
Engine_Status=str(input("Enter Engine status"))
Downtown=int(input("Enter Down time")) 


# EQUIPMENT CONDITION MONITORING
Temperature = int(input("Enter Temparature"))
Vibration= int(input("Enter Vibration"))
if Temperature <80 and Vibration < 5:
    print ("Normal")
elif Temperature >= 80 and Temperature <= 100 or Vibration >= 5 and Vibration <= 8 :
    print("Warning")
elif Temperature > 100 or Vibration > 8:
    print ("Critical")
else:
    print("Inspection required")